//
//  RETO_V2App.swift
//  RETO_V2
//
//  Created by Enrique Mora on 29/08/23.
//

import SwiftUI

@main
struct RETO_V2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  app_moraApp.swift
//  app_mora
//
//  Created by Juan Daniel Muñoz Dueñas on 17/08/23.
//

import SwiftUI

@main
struct app_moraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
